# Mines Math — protótipo Android

Projeto inicial em Kotlin, com tema preto/azul, calculadora de probabilidades teóricas, permissão de painel flutuante e solicitação de captura de tela autorizada pelo Android.

## Limitações importantes
- Não prevê a posição real de minas em rodadas aleatórias.
- A captura de tela é iniciada com autorização explícita do Android.
- **A detecção automática da grade ainda não está implementada**: o serviço recebe imagens, mas não as classifica em casas. O protótipo não deve ser apresentado como detector de minas.
- A probabilidade por casa considera distribuição uniforme de `M` minas em 25 casas: chance de casa livre = `(25-M)/25`.
- Duas casas específicas livres, sem reposição: `((25-M)/25) × ((24-M)/24)`.
- O painel flutuante é um protótipo básico; pode ser necessário ajustar compatibilidade conforme a versão do Android/fabricante.
- Use apenas em conformidade com as regras do site e a legislação local. Não arrisque dinheiro que não pode perder.

## Como compilar o APK
1. Instale o **Android Studio** em um computador.
2. Extraia este ZIP.
3. No Android Studio, escolha **Open** e selecione a pasta `MinesMathAndroid` (a pasta que contém `settings.gradle.kts`).
4. Aguarde o Gradle sincronizar. Se solicitado, instale Android SDK Platform 35 e use JDK 17.
5. Vá em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de debug normalmente aparece em `app/build/outputs/apk/debug/app-debug.apk`.

## Como instalar no celular
1. Copie `app-debug.apk` para o Android.
2. Abra o arquivo e permita a instalação por essa fonte, se o Android solicitar.
3. Abra **Mines Math**.
4. Para o painel, toque em **Ativar painel flutuante** e conceda a permissão.
5. Para captura, toque em **Autorizar captura de tela** e confirme a caixa de diálogo do Android.

## Próxima etapa de desenvolvimento
Implementar processamento de imagem que detecte a grade 5×5 e leia o estado visual das casas. Isso pode reconhecer casas já reveladas, mas não deve afirmar que prevê casas ocultas sem informação legítima sobre a geração da rodada.

## Compilar usando somente o celular (GitHub Actions)
Este projeto inclui `.github/workflows/android.yml` para gerar o APK na nuvem, sem instalar Android Studio no celular.

1. Entre/crie uma conta em https://github.com/ e crie um repositório novo.
2. No navegador do celular, abra o repositório e use **Add file > Upload files** para enviar os arquivos e pastas desta pasta do projeto. Envie também a pasta oculta `.github/workflows` (se o site não permitir enviar a pasta oculta pelo navegador, use o app GitHub ou GitHub Codespaces; não apague o workflow).
3. Faça **Commit changes** na branch `main`.
4. Abra a aba **Actions**, selecione **Build Android APK** e toque em **Run workflow** se a compilação não começar automaticamente.
5. Quando terminar com marca verde, abra a execução e baixe o artefato **MinesMath-debug-apk**. Dentro do ZIP estará `app-debug.apk`.

O GitHub pode pedir confirmação de permissões para executar Actions. O APK gerado é de depuração e não está publicado na Play Store. A compilação na nuvem pode falhar se houver incompatibilidade de dependências; neste caso, veja os logs da execução.
