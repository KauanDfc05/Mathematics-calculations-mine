package br.com.minesmath

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val blue = 0xFF168BFF.toInt()
    private val bg = 0xFF080D16.toInt()
    private val card = 0xFF121C2B.toInt()
    private val captureRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(22, 28, 22, 22)
            setBackgroundColor(bg)
        }
        root.addView(TextView(this).apply {
            text = "MINES MATH\n"; textSize = 28f; setTextColor(blue)
        })
        root.addView(TextView(this).apply {
            text = "Análise matemática • Painel flutuante"; textSize = 15f
            setTextColor(-1); setPadding(0, 0, 0, 18)
        })
        root.addView(TextView(this).apply {
            text = "Aviso: as probabilidades não revelam a posição real de minas aleatórias. Este protótipo calcula chances teóricas e permite capturar a tela com sua autorização."
            textSize = 14f; setTextColor(0xFFB8C6D9.toInt()); setPadding(14,14,14,14)
            setBackgroundColor(card)
        })
        val mines = EditText(this).apply {
            hint = "Quantidade de minas (ex.: 3)"; setHintTextColor(0xFF9BAEC5.toInt())
            setTextColor(-1); inputType = 2; setSingleLine(true)
        }
        root.addView(mines)
        val calc = button("CALCULAR PROBABILIDADES") {
            val n = mines.text.toString().toIntOrNull()
            if (n == null || n !in 1..24) {
                result.text = "Informe de 1 a 24 minas numa grade de 25 casas."
            } else {
                val safe = (25 - n) / 25.0 * 100
                val two = ((25-n).toDouble()/25.0)*((24-n).coerceAtLeast(0).toDouble()/24.0)*100
                result.text = "Casa escolhida livre (antes de revelar): %.2f%%\nDuas casas específicas livres: %.2f%%\n\nIsto assume distribuição uniforme e não identifica casas seguras.".format(safe, two)
            }
        }
        root.addView(calc)
        val result = TextView(this).apply {
            text = "Os resultados aparecerão aqui."; textSize = 15f; setTextColor(-1)
            setPadding(14,18,14,18); setBackgroundColor(card)
        }
        root.addView(result)
        root.addView(button("ATIVAR PAINEL FLUTUANTE") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
                Toast.makeText(this, "Permita 'Exibir sobre outros apps' e toque novamente.", Toast.LENGTH_LONG).show()
            } else startService(Intent(this, FloatingPanelService::class.java))
        })
        root.addView(button("AUTORIZAR CAPTURA DE TELA") {
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
        })
        root.addView(TextView(this).apply {
            text = "A captura é iniciada somente após confirmação do Android. Protótipo: a imagem ainda não é interpretada automaticamente para localizar a grade."
            textSize = 12f; setTextColor(0xFF9BAEC5.toInt()); setPadding(0,16,0,0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private lateinit var result: TextView

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; setTextColor(-1); setBackgroundColor(blue)
        setOnClickListener { action() }
    }

    @Deprecated("Legacy callback used for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == Activity.RESULT_OK && data != null) {
            val i = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra("resultCode", resultCode); putExtra("data", data)
            }
            startForegroundService(i)
            Toast.makeText(this, "Captura autorizada. Veja a notificação do serviço.", Toast.LENGTH_LONG).show()
        }
    }
}
