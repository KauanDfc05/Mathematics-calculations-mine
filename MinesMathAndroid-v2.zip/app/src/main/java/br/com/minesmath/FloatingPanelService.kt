package br.com.minesmath

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*

class FloatingPanelService : Service() {
    private var window: WindowManager? = null
    private var panel: View? = null
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel != null) return START_NOT_STICKY
        window = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(14,10,14,10)
            setBackgroundColor(0xEE101B2B.toInt())
        }
        box.addView(TextView(this).apply { text = "MINES MATH  ⋮"; textSize = 16f; setTextColor(0xFF168BFF.toInt()) })
        box.addView(TextView(this).apply {
            text = "Probabilidade teórica: informe a quantidade de minas no app principal."
            textSize = 12f; setTextColor(-1)
        })
        box.addView(Button(this).apply {
            text = "Fechar painel"
            setOnClickListener { stopSelf() }
        })
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 180 }
        box.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                if (e.action == MotionEvent.ACTION_DOWN) {
                    downX=e.rawX; downY=e.rawY; startX=params.x; startY=params.y; return true
                }
                if (e.action == MotionEvent.ACTION_MOVE) {
                    params.x = startX + (downX-e.rawX).toInt()
                    params.y = startY + (e.rawY-downY).toInt()
                    window?.updateViewLayout(box, params); return true
                }
                return false
            }
        })
        panel = box
        window?.addView(box, params)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        panel?.let { try { window?.removeView(it) } catch (_: Exception) {} }
        panel = null; super.onDestroy()
    }
}
