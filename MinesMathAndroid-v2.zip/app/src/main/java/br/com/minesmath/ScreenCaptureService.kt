package br.com.minesmath

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        val code = intent?.getIntExtra("resultCode", 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") (intent?.getParcelableExtra("data") as? Intent)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, android.os.Handler(mainLooper))
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        reader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "MinesMathCapture", metrics.widthPixels, metrics.heightPixels, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null
        )
        reader?.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage()
            if (image != null) {
                // Captura autorizada recebida. Próxima etapa do projeto: detectar a grade via visão computacional.
                image.close()
            }
        }, null)
        return START_NOT_STICKY
    }

    private fun createNotification() {
        val channelId = "mines_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Captura de tela", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId).setContentTitle("Mines Math")
                .setContentText("Captura de tela autorizada ativa").setSmallIcon(android.R.drawable.ic_menu_view).build()
        else @Suppress("DEPRECATION") (Notification.Builder(this).setContentTitle("Mines Math")
                .setContentText("Captura de tela autorizada ativa").setSmallIcon(android.R.drawable.ic_menu_view).build())
        startForeground(7, notification)
    }

    override fun onDestroy() {
        display?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
}
